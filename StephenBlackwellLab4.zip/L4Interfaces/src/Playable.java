
public interface Playable {
	public void guess(String s);
		
	public boolean isOver();
	
	public String getStatus();
}
